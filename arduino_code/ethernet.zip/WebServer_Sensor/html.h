void alert(){
  client.println("<h1><font color='red'><strong>WARNING</strong></font></h1>");
  client.println("<br><br>");
}
void makeOnSwitch(){
  client.print("<form action='/led' method='GET'>");
  client.print("<input type='hidden' name='pinD8' value='on'>");
  client.print("<input class='onBtn' type='submit' value='on'/>");
  client.print("</form>");  
}
void makeOffSwitch(){  
  client.print("<form action='/led' method='GET'>");
  client.print("<input type='hidden' name='pinD8' value='off'>");
  client.print("<input class='onBtn' type='submit' value='off'/>"); 
  client.print("</form>"); 
}
void setHtml(){
  client.println("HTTP/1.1 200 OK");
  client.println("Content-Type: text/html");
  client.println("Connection: close");  // the connection will be closed after completion of the response
  client.println("Refresh: 5");  // refresh the page automatically every 5 sec
  client.println();
  client.println("<!DOCTYPE HTML>");
  client.println("<html>");
  client.println("<title>Arduino for IoT</title>");
  client.println("<head>");
  client.println("<script>");
  client.println("function at() {document.location='/';}");
  client.println("setTimeout(at, 1000);");
  client.println("</script>");
  client.println("<style>");
  client.println("h1{color:#17A1A5; font-size:48px;}");
   if (isWarning) {
    client.println("body{background-color:orange;}");
   }
  client.println(".box{border:solid 5px #4db7bb; width:25%; height: 190px;}");
  client.println("input{width:40%; height: 100px; font-size:40px; color:#fff; border:none; background: #17A1A5;}");
  client.println(".onBtn{margin:40px 0 20px 0;}");
  client.println("</style>");
  client.println("</head>");
  client.println("<body>");
  client.println("<center>");
  client.println("<br>");
  client.println("<h1>Security with Arduino</h1>");
  client.println("<br>");
  if (isWarning) {
    alert();
    client.println("<div class=\"box\">");    
    if (isOnSwitchClick) {
      makeOffSwitch();
    } else {
      makeOnSwitch();     
    } 
  }
  client.println("</div>");
  client.println("</center>");
  client.println("<br />");
  client.println("</body>");
  client.println("</html>");
}